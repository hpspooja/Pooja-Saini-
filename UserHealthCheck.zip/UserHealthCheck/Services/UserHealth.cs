﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using UserHealthCheck.Models;

namespace UserHealthCheck.Services
{
    public class UserHealth //: IUserHealth
    {
       public string UserHealthPoint(int id)
        {
            // can include business object and data access layer but returning some  hard coded values \
            // can get data from data base
            try
            {
                List<UserModel> users = new List<UserModel>()
        {
            new UserModel()
                {
                    UserId = 1, UserName = "Mukesh Kumar", UserEmail = "MukeshKumar11@gamil.com",Issue = "No issue", Age = 20
                },
                 new UserModel()
                {
                    UserId = 2, UserName = "Anil Kumar",UserEmail = "AnilKumar14@gamil.com", Issue = "Eye problem", Age = 30
                },
                new UserModel()
                {
                    UserId = 3, UserName = "Pooja Saini", UserEmail = "poojasaini22@gamil.com" ,Issue = "heart", Age = 10
                },
                new UserModel()
                {
                    UserId = 4, UserName = "Siya Saini", Issue = "siyasaini33@gmail.com", Age = 27
                }
        };
                var userDetail = users.FirstOrDefault(x => x.UserId == id);
                if (userDetail != null)
                {
                    if (userDetail.Issue == "No issue")
                    {
                        return "OK";
                    }
                    else
                    {
                        return "NOT OK";
                    }
                }
                else
                    return "user not found";
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
      public  string UserCheckPoint(string name)
        {
            return name;
        }
    }
}