﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UserHealthCheck.Models
{
    public class UserModel
    {
        public int UserId
        {
            get;
            set;
        }
        public string UserName
        {
            get;
            set;
        }
        public string UserEmail
        {
            get;
            set;
        }
        public string Issue
        {
            get;
            set;
        }
        public int Age
        {
            get;
            set;
        }
    }
    public class Name
    {
        public string Title { get; set; }
        public string First { get; set; }
        public string Last { get; set; }
    }

    public class Result
    {
        public Name Name { get; set; }
    }

    public class Person
    {
        public List<Result> Results { get; set; }
    }
}