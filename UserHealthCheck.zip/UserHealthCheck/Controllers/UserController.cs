﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using UserHealthCheck.Models;
using UserHealthCheck.Services;

namespace UserHealthCheck.Controllers
{
    //[Route("api/user")]
    public class UserController : ApiController
    {

        //public UserController(IUserHealth userHealth)
        //{
        //    _userHealth = userHealth;

        //}
        
        [HttpGet]
        public IHttpActionResult HealthCheck(int userId)
        {
            UserHealth ob = new UserHealth();
            var userDetails = ob.UserHealthPoint(userId);
         
                if (userDetails == "OK")
                {
                    return StatusCode(HttpStatusCode.OK);
                }
                else
                {
                    return StatusCode(HttpStatusCode.OK);
                }
            

        }
       [BasicAuthentication]
        [HttpGet]
        public async Task<Name> UserEndPoint()
        {
            HttpClient client = new HttpClient
            {
                BaseAddress = new Uri("https://api.randomuser.me")
            };
            HttpResponseMessage response = await client.GetAsync("https://randomuser.me/api/");
            response.EnsureSuccessStatusCode();

            var stringResult = await response.Content.ReadAsStringAsync();
            Person root = JsonConvert.DeserializeObject<Person>(stringResult);
            return root.Results[0].Name;
        }
    }
}
