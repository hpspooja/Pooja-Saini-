﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using UserHealthCheck.Models;

namespace UserHealthCheck
{
    public class userSecurity
    {
        public static bool Login (string uname, string pass)
        {
            // can use Db context 

            List<UserLogin> users = new List<UserLogin>()
        {
            new UserLogin()
                {
                    UserName = "Mukesh Kumar", Password = "12345"
                },
                 new UserLogin()
                {
                   UserName = "Anil Kumar",Password = "A12345"
                },
                new UserLogin()
                {
                     UserName = "Pooja Saini", Password = "p12345" 
                },
                new UserLogin()
                {
                    UserName = "Siya Saini", Password = "s12345"
                }
        };

            //using (testEntities entity = new testEntities())
            //{
            return users.Any(x => x.UserName.Equals(uname, StringComparison.OrdinalIgnoreCase) && x.Password == pass);
           // }
        }
    }
}